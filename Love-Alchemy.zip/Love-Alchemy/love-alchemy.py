from flask import Flask, request, render_template
import joblib
import pandas as pd
import numpy as np

# Load the saved model and preprocessing artifacts
model = joblib.load('models/best_love_compatibility_model.joblib')
scaler = joblib.load('models/love_compatibility_scaler.joblib')
label_encoders = joblib.load('models/love_compatibility_label_encoders.joblib')

# Zodiac compatibility mapping
zodiac_compatibility = {
    "Aries": ["Leo", "Sagittarius"],
    "Taurus": ["Virgo", "Capricorn"],
    "Gemini": ["Libra", "Aquarius"],
    "Cancer": ["Scorpio", "Pisces"],
    "Leo": ["Aries", "Sagittarius"],
    "Virgo": ["Taurus", "Capricorn"],
    "Libra": ["Gemini", "Aquarius"],
    "Scorpio": ["Cancer", "Pisces"],
    "Sagittarius": ["Aries", "Leo"],
    "Capricorn": ["Taurus", "Virgo"],
    "Aquarius": ["Gemini", "Libra"],
    "Pisces": ["Cancer", "Scorpio"]
}

# Hobby compatibility mapping
hobby_compatibility = {
    "Reading": ["Traveling", "Drawing"],
    "Gaming": ["Photography", "Hiking"],
    "Hiking": ["Fishing", "Gaming"],
    "Fishing": ["Hiking", "Traveling"],
    "Cooking": ["Drawing", "Photography"],
    "Drawing": ["Reading", "Cooking"],
    "Traveling": ["Reading", "Fishing"],
    "Photography": ["Gaming", "Cooking"]
}

# Favorite color compatibility mapping
color_compatibility = {
    "Red": ["Pink", "White"],
    "Blue": ["Green", "White"],
    "Green": ["Blue", "Yellow"],
    "Yellow": ["Green", "Orange"],
    "Purple": ["Pink", "Blue"],
    "Brown": ["Yellow", "Orange"],
    "Black": ["White", "Grey"],
    "White": ["Black", "Blue"],
    "Pink": ["Red", "Purple"]
}

# Movie genre compatibility mapping
movie_genre_compatibility = {
    "Adventure": ["Fantasy", "Sci-Fi"],
    "Fantasy": ["Adventure", "Romance"],
    "Horror": ["Thriller", "Drama"],
    "Romance": ["Fantasy", "Drama"],
    "Comedy": ["Romance", "Adventure"],
    "Thriller": ["Horror", "Drama"],
    "Drama": ["Romance", "Thriller"],
    "Sci-Fi": ["Adventure", "Fantasy"]
}

# Updated compatibility score function
def calculate_score(entry):
    score = 50  # Base score

    # Age difference penalty (smaller is better)
    age_diff = abs(entry["Boy_Age"] - entry["Girl_Age"])
    score -= age_diff * 1.5  # Penalize for each year of difference

    # Matching hobbies or compatible hobbies
    if entry["Boy_Hobby"] == entry["Girl_Hobby"]:
        score += 20
    elif entry["Girl_Hobby"] in hobby_compatibility.get(entry["Boy_Hobby"], []):
        score += 10

    # Matching or compatible favorite colors
    if entry["Boy_FavColor"] == entry["Girl_FavColor"]:
        score += 10
    elif entry["Girl_FavColor"] in color_compatibility.get(entry["Boy_FavColor"], []):
        score += 5

    # Matching or compatible movie genres
    if entry["Boy_FavMovieGenre"] == entry["Girl_FavMovieGenre"]:
        score += 15
    elif entry["Girl_FavMovieGenre"] in movie_genre_compatibility.get(entry["Boy_FavMovieGenre"], []):
        score += 7

    # Zodiac compatibility
    if entry["Girl_Zodiac"] in zodiac_compatibility.get(entry["Boy_Zodiac"], []):
        score += 15

    # Ensure score stays within 0 to 100
    return max(0, min(100, score))

# Define Flask app
app = Flask(__name__)

# Compatibility labels based on percentage thresholds
compatibility_labels = {
    5: "Excellent (90%+)",
    4: "Very Good (80-90%)",
    3: "Good (70-80%)",
    2: "Average (60-70%)",
    1: "Below Average (50-60%)",
    0: "Poor (<50%)"
}

# Funny comments based on compatibility categories
funny_comments = {
    5: "You two are the peanut butter and jelly of relationships! 🥜🍇",
    4: "A match made in heaven, just avoid arguing over pizza toppings! 🍕✨",
    3: "There’s potential, but remember, opposites attract (sometimes). 🧲❤️",
    2: "Love is a journey, not a sprint. Keep working at it! 🚶‍♂️❤️",
    1: "Some sparks need more kindling to ignite. 🔥",
    0: "Cupid might need a GPS for this one! 🏹🗺️"
}

# Home route
@app.route('/')
def home():
    return render_template('index.html', compatibility_percentage=None, comment=None)

# Prediction API route
@app.route('/predict', methods=['POST'])
def predict():
    data = request.form

    # Extract input data
    boy_features = {
        'Boy_Age': int(data['boy_age']),
        'Boy_FavColor': data['boy_fav_color'],
        'Boy_Hobby': data['boy_hobby'],
        'Boy_FavMovieGenre': data['boy_movie_genre'],
        'Boy_Zodiac': data['boy_zodiac']
    }

    girl_features = {
        'Girl_Age': int(data['girl_age']),
        'Girl_FavColor': data['girl_fav_color'],
        'Girl_Hobby': data['girl_hobby'],
        'Girl_FavMovieGenre': data['girl_movie_genre'],
        'Girl_Zodiac': data['girl_zodiac']
    }

    # Prepare features
    features_df = pd.DataFrame({**boy_features, **girl_features}, index=[0])

    # Encode categorical features
    categorical_features = [
        'Boy_FavColor', 'Girl_FavColor',
        'Boy_Hobby', 'Girl_Hobby',
        'Boy_FavMovieGenre', 'Girl_FavMovieGenre',
        'Boy_Zodiac', 'Girl_Zodiac'
    ]

    for feature in categorical_features:
        if features_df[feature].iloc[0] not in label_encoders[feature].classes_:
            # Add unseen labels dynamically
            label_encoders[feature].classes_ = np.append(label_encoders[feature].classes_, features_df[feature].iloc[0])
        features_df[feature] = label_encoders[feature].transform(features_df[feature])

    # Calculate age difference
    features_df['Age_Difference'] = abs(features_df['Boy_Age'] - features_df['Girl_Age'])

    # Select and scale features
    feature_columns = [
        'Boy_Age', 'Girl_Age', 'Age_Difference',
        'Boy_FavColor', 'Girl_FavColor',
        'Boy_Hobby', 'Girl_Hobby',
        'Boy_FavMovieGenre', 'Girl_FavMovieGenre',
        'Boy_Zodiac', 'Girl_Zodiac'
    ]

    X_new = features_df[feature_columns]

    try:
        # Scale features
        X_new_scaled = scaler.transform(X_new)

        # Predict
        prediction = model.predict(X_new_scaled)[0]
        prediction_proba = model.predict_proba(X_new_scaled)[0][prediction]

        # Calculate compatibility percentage
        compatibility_percentage = round(prediction_proba * 100, 2)

        # Check if prediction is reasonable; fallback to rule-based if unreasonable
        if compatibility_percentage < 50 or compatibility_percentage > 100:
            raise ValueError("Model predicted an unreasonable compatibility percentage.")

    except Exception as e:
        print("Model failed to predict or gave an unreasonable result:", e)

        # Fall back to rule-based scoring
        compatibility_percentage = calculate_score({
            **boy_features,
            **girl_features
        })

    # Map percentage to compatibility label and funny comment
    if compatibility_percentage >= 90:
        compatibility_category = 5
    elif compatibility_percentage >= 80:
        compatibility_category = 4
    elif compatibility_percentage >= 70:
        compatibility_category = 3
    elif compatibility_percentage >= 60:
        compatibility_category = 2
    elif compatibility_percentage >= 50:
        compatibility_category = 1
    else:
        compatibility_category = 0

    compatibility_label = compatibility_labels[compatibility_category]
    comment = funny_comments[compatibility_category]

    # Log processed input and predictions for debugging
    print("Processed Features:", features_df.to_dict(orient='records'))
    print("Compatibility Percentage:", compatibility_percentage)

    # Render results to the template
    return render_template(
        'index.html',
        boy_name=data['boy_name'],
        girl_name=data['girl_name'],
        compatibility_percentage=compatibility_percentage,
        compatibility_label=compatibility_label,
        comment=comment
    )

if __name__ == '__main__':
    app.run(debug=True)

